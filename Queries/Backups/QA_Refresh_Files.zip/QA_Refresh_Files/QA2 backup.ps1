Move-Item "\\utqa-sql-14\e$\SQL\Data05\BSSMessageQueue.mdf" "\\utqa-sql-14\D$\SQLBACKUP\BSSMessageQueue.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\BSSMessageQueue_log.ldf"  "\\utqa-sql-14\D$\SQLBACKUP\BSSMessageQueue_log.ldf" 


Move-Item "\\utqa-sql-14\e$\SQL\Data01\DBA.mdf" "\\utqa-sql-14\D$\SQLBACKUP\DBA.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\DBA_log.ldf"  "\\utqa-sql-14\D$\SQLBACKUP\DBA_log.ldf" 

Move-Item "\\utqa-sql-14\e$\SQL\Data05\LFP.mdf" "\\utqa-sql-14\D$\SQLBACKUP\LFP.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\LFP_log.ldf"  "\\utqa-sql-14\D$\SQLBACKUP\LFP_log.ldf" 

Move-Item "\\utqa-sql-14\e$\SQL\Data05\Perfstats.mdf" "\\utqa-sql-14\Q$\SQLBACKUP\Perfstats.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\Perfstats_log.ldf"  "\\utqa-sql-14\Q$\SQLBACKUP\Perfstats_log.ldf" 


Move-Item "\\utqa-sql-14\e$\SQL\Data05\LIMC.mdf" "\\utqa-sql-14\D$\SQLBACKUP\LIMC.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\LIMC_log.ldf"  "\\utqa-sql-14\D$\SQLBACKUP\LIMC_log.ldf" 


Move-Item "\\utqa-sql-14\e$\SQL\Data05\UnitracHDStorage.mdf" "\\utqa-sql-14\D$\SQLBACKUP\UnitracHDStorage.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\UnitracHDStorage_log.ldf"  "\\utqa-sql-14\D$\SQLBACKUP\UnitracHDStorage_log.ldf" 



Move-Item "\\utqa-sql-14\e$\SQL\Data05\VehicleCT.mdf" "\\utqa-sql-14\D$\SQLBACKUP\VehicleCT.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\VehicleCT_log.ldf"  "\\utqa-sql-14\D$\SQLBACKUP\VehicleCT_log.ldf" 

Move-Item "\\utqa-sql-14\e$\SQL\Data05\VehicleUC.mdf" "\\utqa-sql-14\D$\SQLBACKUP\VehicleUC.mdf"
Move-Item "\\utqa-sql-14\e$\SQL\SQLLogs\VehicleUC_log.ldf"  "\\utqa-sql-14\D$\SQLBACKUP\VehicleUC_log.ldf"


Move-Item "\\utqa-sql-14\e$\SQL\Data05\HDTStorage.mdf" "\\utqa-sql-14\D$\SQLBACKUP\HDTStorage.mdf"
Move-Item  "\\utqa-sql-14\e$\SQL\SQLLogs\HDTStorage_log.ldf" "\\utqa-sql-14\D$\SQLBACKUP\HDTStorage_log.ldf" 