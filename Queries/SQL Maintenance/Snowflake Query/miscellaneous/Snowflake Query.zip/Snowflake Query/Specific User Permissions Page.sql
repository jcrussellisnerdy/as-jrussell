USE ROLE ACCOUNTADMIN;

--Show what access users has 
SHOW GRANTS TO USER identifier('"MLOCKARD"');


---Show Grants to warehouse
SHOW GRANTS ON WAREHOUSE bond_test_infa_wh

--READWRITE_BOND_DEV
--READ_BOND_DEV

---Show Grants to user
show grants to user VGLASCOCK; 

--Shows Permissions 
SHOW GRANTS TO ROLE DATASCIENCE;
 
--Show users 
SHOW GRANTS OF OWNER_EDW_TEST;

 
--Show users 
SHOW GRANTS OF DATASCIENCE;


 
--Show users 
SHOW GRANTS OF EDW_BI_READER;


--Show access by database
SHOW FUTURE GRANTS IN DATABASE SNOWFLAKE ;


--Show access by warehouse
SHOW GRANTS ON  STG_UT_FINANCIAL_TXN ;

--Show access by schema (database.schema)
show future grants in schema STG.delim_lkp;

--Show access by table (schema.table)
show grants on table EDW_TEST.STG.STG_UT_INTERACTION_HISTORY_ARCHIVE;

show warehouses like 'webfocus%';
bond_dev_infa_wh

use role accountadmin;

grant usage on database EDW_TEST to role OWNER_EDW_PROD;
grant usage on future schemas in database EDW_TEST to role OWNER_EDW_PROD;
grant select on future tables in database EDW_TEST to role OWNER_EDW_PROD;


GRANT ROLE "EDW_ALLIED_EMPLOYEES" TO USER "MLOCKARD"


----Grant import users to shared database  (https://community.snowflake.com/s/article/Error-Granting-individual-privileges-on-imported-database-is-not-allowed-Use-GRANT-IMPORTED-PRIVILEGES-instead)
--grant IMPORTED PRIVILEGES on database SNOWFLAKE to role OWNER_EDW_DEV; 
--revoke IMPORTED PRIVILEGES on database SNOWFLAKE FROM EDW_CONTRACTORS

--GRANT ROLE "EDW_ALLIED_EMPLOYEES" TO USER "ALCLARK";
--GRANT ROLE "EDW_BI_READER" to USER "ALCLARK";
--GRANT ROLE "EDW_PROD_SUPPORT" TO USER "ALCLARK";
--GRANT ROLE "BOND_ALLIED_EMPLOYEES" TO USER "ALCLARK";

--Assign roles to users (These are commented out in the event this gets accidentally fully ran )
--GRANT ROLE "BOND_ALLIED_EMPLOYEES" TO USER "RPARIHAR";
--GRANT ROLE "EDW_ALLIED_EMPLOYEES" TO USER "RPARIHAR";
--GRANT ROLE "EDW_PROD_SUPPORT" TO USER "RPARIHAR";
--GRANT ROLE DATASCIENCE to USER JRUSSELL  ;
--GRANT ROLE "EDW_BI_READER" to USER "JRUSSELL";  

--Revoke roles to users  (These are commented out in the event this gets accidentally fully ran )
--REVOKE ROLE "EDW_ALLIED_EMPLOYEES"  FROM USER "RPARIHAR";
--REVOKE ROLE "BOND_ALLIED_EMPLOYEES"  FROM USER "RPARIHAR"
--REVOKE ROLE DATASCIENCE to USER JRUSSELL  ;
--REVOKE ROLE EDW_BI_READER to USER JRUSSELL ; 



/*

Last time user logged in: 

select *
from table(information_schema.login_history_by_user('jrussell', result_limit=>1000))
order by event_timestamp;


select *
from table(information_schema.login_history(dateadd('hours',-3,current_timestamp()),current_timestamp()))
order by event_timestamp desc;


select *
from table(information_schema.login_history(dateadd('hours',-48,current_timestamp()),current_timestamp()))
WHERE REPORTED_CLIENT_TYPE = 'SNOWFLAKE_UI'
order by event_timestamp desc;




select *
from table(information_schema.login_history(dateadd('day',-6,current_timestamp()),current_timestamp()))
WHERE ERROR_MESSAGE is not null
order by event_timestamp desc;

select *
from table(information_schema.login_history(dateadd('hours',-3,current_timestamp()),current_timestamp()))
WHERE REPORTED_CLIENT_TYPE != 'SNOWFLAKE_UI'
order by event_timestamp desc;

https://community.snowflake.com/s/article/How-to-grant-select-on-all-future-tables-in-a-schema-and-database-level

1. Schema level:
 
use role accountadmin;
create database MY_DB;
grant usage on database MY_DB to role TEST_ROLE;
grant usage on schema MY_DB.MY_SCHEMA to role TEST_ROLE;
grant select on future tables in schema MY_DB.MY_SCHEMA to role TEST_ROLE;


 2. Database Level:  (assuming the privileges are granted from scratch)
 
use role accountadmin;
create database MY_DB;
grant usage on database MY_DB to role TEST_ROLE;
grant usage on future schemas in database MY_DB to role TEST_ROLE;
grant select on future tables in database MY_DB to role TEST_ROLE;


*/
