﻿Install-WindowsFeature Desktop-Experience


Install-WindowsFeature -name Web-Server -IncludeManagementTools