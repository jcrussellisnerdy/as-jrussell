﻿Get-Service -ComputerName UT-STGAPP-02 -Name LDHONEMAIN |Start-Service

Get-Service -ComputerName UTSTAGE-APP4 -Name MSGSRVRONEMAIN |Start-Service
