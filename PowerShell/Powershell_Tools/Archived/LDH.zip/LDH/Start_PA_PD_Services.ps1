﻿Get-Service	 -ComputerName	UNITRAC-WH01	  -Name	LDHServicePRCPA	|  Start-Service

Get-Service	 -ComputerName	UNITRAC-APP02	  -Name	LDHServiceUSD	|  Start-Service










