﻿Get-Service	 -ComputerName	UNITRAC-WH01	  -Name	LDHServicePRCPA	

Get-Service	 -ComputerName	UNITRAC-APP02	  -Name	LDHServiceUSD	