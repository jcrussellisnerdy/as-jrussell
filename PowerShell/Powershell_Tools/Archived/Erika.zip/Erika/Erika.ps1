﻿ Get-Service	 -ComputerName	UNITRAC-WH14	  -Name	DIRECTORYWATCHERSERVERIN	|  Restart-Service
Get-Service	 -ComputerName	UNITRAC-WH14	  -Name	DIRECTORYWATCHERSERVEROUT	|   Restart-Service
Get-Service	 -ComputerName	UNITRAC-WH08	  -Name	MSGSRVRDEF	|   Restart-Service