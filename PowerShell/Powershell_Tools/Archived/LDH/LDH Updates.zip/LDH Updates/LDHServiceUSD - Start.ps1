﻿

Get-Service	 -ComputerName	UNITRAC-APP02	  -Name	LDHServiceUSD	|  Start-Service