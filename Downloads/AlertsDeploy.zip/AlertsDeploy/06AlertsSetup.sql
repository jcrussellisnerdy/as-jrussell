


/***********************************************************


			Alert Configuration


**************************************************************/

Declare @AlertName nvarchar(256)
Declare @condition nvarchar(512)
Declare @Operator nvarchar(256)

--set @Operator = N'asdf'

If Not exists(Select name from msdb.dbo.sysalerts where severity = 16 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 16]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 16', 
			@message_id=0, 
			@severity=16, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 16', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 16 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=16, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'

	End




If Not exists(Select name from msdb.dbo.sysalerts where severity = 17 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 17]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 17', 
			@message_id=0, 
			@severity=17, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 17', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 17 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=17, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'

	End





If Not exists(Select name from msdb.dbo.sysalerts where severity = 19 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 19]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 19', 
			@message_id=0, 
			@severity=19, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 19', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 19 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=19, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End



If Not exists(Select name from msdb.dbo.sysalerts where severity = 20 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 20]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 20', 
			@message_id=0, 
			@severity=20, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 20', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 20 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=20, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	
		
	End



If Not exists(Select name from msdb.dbo.sysalerts where severity = 21 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 21]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 21', 
			@message_id=0, 
			@severity=21, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 21', @operator_name=@Operator, @notification_method = 1
	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 21 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=21, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	
		
	End




If Not exists(Select name from msdb.dbo.sysalerts where severity = 22 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 22]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 22', 
			@message_id=0, 
			@severity=22, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 22', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 22 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=22, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	
		
	End



If Not exists(Select name from msdb.dbo.sysalerts where severity = 23 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 23]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 23', 
			@message_id=0, 
			@severity=23, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 23', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 23 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=23, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End




If Not exists(Select name from msdb.dbo.sysalerts where severity = 24 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 24]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 24', 
			@message_id=0, 
			@severity=24, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 24', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 24 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=24, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End


If Not exists(Select name from msdb.dbo.sysalerts where severity = 25 and message_id = 0)
	Begin
		/****** Object:  Alert [Alert Severity 25]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Alert Severity 25', 
			@message_id=0, 
			@severity=25, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Alert Severity 25', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 25 and message_id = 0

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=0, 
			@severity=25, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End



If Not exists(Select name from msdb.dbo.sysalerts where severity = 0 and message_id = 833)
	Begin
		/****** Object:  Alert [IO errors]    Script Date: 01/08/2013 13:51:19 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'IO errors', 
			@message_id=833, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'IO errors', @operator_name=@Operator, @notification_method = 1
	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 0 and message_id = 833

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=833, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End


If Not exists(Select name from msdb.dbo.sysalerts where severity = 0 and message_id = 15457)
	Begin
		/****** Object:  Alert [Error 15457 (Config Change)]    Script Date: 02/22/2012 09:13:30 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Config Change', 
			@message_id=15457, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=0, 
			@include_event_description_in=0, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Config Change', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 0 and message_id = 15457

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=15457, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	
	End


If Not exists(Select name from msdb.dbo.sysalerts where severity = 0 and message_id = 825)
	Begin
		/****** Object:  Alert [Error 825 -- Potential Drive Failure]    Script Date: 02/22/2012 09:13:30 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Potential Drive Failure', 
			@message_id=825, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=15, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Potential Drive Failure', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 0 and message_id = 825

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=825, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End


If Not exists(Select name from msdb.dbo.sysalerts where severity = 0 and message_id = 823)
	Begin
		/****** Object:  Alert [Error 825 -- Potential Drive Failure]    Script Date: 02/22/2012 09:13:30 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Moser_823', 
			@message_id=823, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=15, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Moser_823', @operator_name=@Operator, @notification_method = 1



	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 0 and message_id = 823

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=823, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End


If Not exists(Select name from msdb.dbo.sysalerts where severity = 0 and message_id = 824)
	Begin
		/****** Object:  Alert [Error 825 -- Potential Drive Failure]    Script Date: 02/22/2012 09:13:30 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'824', 
			@message_id=824, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=15, 
			@include_event_description_in=1, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'824', @operator_name=@Operator, @notification_method = 1


	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 0 and message_id = 824

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=824, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End


If Not exists(Select name from msdb.dbo.sysalerts where severity = 0 and message_id = 18456)
	Begin
		/****** Object:  Alert [Login Failure]    Script Date: 02/22/2012 09:13:30 ******/
		EXEC msdb.dbo.sp_add_alert @name=N'Login Failure', 
			@message_id=18456, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=5, 
			@include_event_description_in=3, 
			@category_name=N'[Uncategorized]', 
			@job_name=N'Capture Alerts'

			--EXEC msdb.dbo.sp_add_notification @alert_name=N'Login Failure', @operator_name=@Operator, @notification_method = 1

	End
Else
	Begin
		Select @AlertName = name from msdb.dbo.sysalerts where severity = 0 and message_id = 18456

		EXEC msdb.dbo.sp_update_alert @name=@AlertName, 
			@message_id=18456, 
			@severity=0, 
			@enabled=1, 
			@delay_between_responses=300, 
			@include_event_description_in=1, 
			@database_name=N'', 
			@notification_message=N'', 
			@event_description_keyword=N'', 
			@performance_condition=N'', 
			@wmi_namespace=N'', 
			@wmi_query=N'', 
			@job_name=N'Capture Alerts'	

	End

GO
