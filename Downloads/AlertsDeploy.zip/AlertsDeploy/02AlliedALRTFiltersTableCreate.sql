USE [DBA]
GO

/****** Object:  Table [alert].[Filters]    Script Date: 3/17/2020 1:54:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Alert' AND  TABLE_NAME = 'Filters'))
BEGIN
	truncate TABLE [alert].[Filters]

	--Adds filter to eliminate 3 emails being sent for every one Instance Configuration Change.
	INSERT  [alert].[Filters]           (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 15457, 10, '@message like ''%show advanced options%''', 1, GETDATE(), 'Moser', 'This will elminate the Show Advance Options notifications'

	--Adds filter to eliminate emails being sent for for specific failed user login.
	INSERT  [alert].[Filters]           (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 18456, 14, '@message like ''%LoginID%'' and @message like ''%IPAddress%''', 0, GETDATE(), 'Moser', 'This is a sample for how to create a filter to ignore certain Login and IP address source combinations'


END

IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Alert' AND  TABLE_NAME = 'Filters'))
BEGIN

	CREATE TABLE [alert].[Filters](
		[AF_ID] [int] IDENTITY(1,1) NOT NULL,
		[AF_Error] [int] NOT NULL,
		[AF_Severity] [int] NOT NULL,
		[AF_MSG_Contains] [varchar](4000) NULL,
		[AF_Enabled] [bit] NULL,
		[AF_DateCreated] [datetime] NULL,
		[AF_CreatedBy] [varchar](256) NOT NULL,
		[AF_Description] [varchar](4000) NOT NULL,
		[AF_ExpirationDate] [datetime] NULL
	) ON [PRIMARY]
	

	ALTER TABLE [alert].[Filters] ADD  DEFAULT ((1)) FOR [AF_Enabled]

	ALTER TABLE [alert].[Filters] ADD  DEFAULT (getdate()) FOR [AF_DateCreated]

	ALTER TABLE [alert].[Filters] ADD  DEFAULT ('12/31/2029') FOR [AF_ExpirationDate]

	--Adds filter to eliminate 3 emails being sent for every one Instance Configuration Change.
	INSERT  [alert].[Filters]           (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 15457, 10, '@message like ''%show advanced options%''', 1, GETDATE(), 'Moser', 'This will elminate the Show Advance Options notifications'

	--Adds filter to eliminate emails being sent for for specific failed user login.
	INSERT  [alert].[Filters]           (AF_Error, AF_Severity, AF_MSG_Contains, AF_Enabled, AF_DateCreated, AF_CreatedBy, AF_Description)
	SELECT 18456, 14, '@message like ''%LoginID%'' and @message like ''%IPAddress%''', 0, GETDATE(), 'Moser', 'This is a sample for how to create a filter to ignore certain Login and IP address source combinations'

END
