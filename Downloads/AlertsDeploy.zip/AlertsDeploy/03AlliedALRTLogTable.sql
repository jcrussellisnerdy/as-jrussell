USE [DBA]
GO

/****** Object:  Table [alert].[Log]    Script Date: 3/17/2020 1:54:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'alert' AND  TABLE_NAME = 'Log'))
BEGIN
	DROP TABLE [alert].[Log]
END


IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'alert' AND  TABLE_NAME = 'Log'))
BEGIN
	CREATE TABLE [alert].[Log](
		[AL_ID] [int] IDENTITY(1,1) NOT NULL,
		[Database] [nvarchar](200) NOT NULL,
		[Server] [nvarchar](200) NOT NULL,
		[Date] [int] NOT NULL,
		[Time] [int] NOT NULL,
		[Severity] [int] NOT NULL,
		[Error] [int] NOT NULL,
		[Message] [nvarchar](3000) NOT NULL
	) ON [PRIMARY]
END
