1. Deploy scripts in order of number.  Can use a Powershell script to deploy all .sql files in the folder
2. If Queued Alerts are desired, run through files in QueuedAlerts in order after running 01-07 in AlertsDeploy Folder
3. make sure to change @notify_email_operator_name=N'MoserIT' in 06AlliedCaptureAlertsJob if necessary. 
	currently the process calls a job which will then send out an email, it relies on table driven values from alert.parameters to make things
	for Moser easiert to add or remove addresses if consultants go in and out
