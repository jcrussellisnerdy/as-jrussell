USE [DBA]
GO

/****** Object:  Table [alert].[Parameters]    Script Date: 3/17/2020 1:53:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

DECLARE @EmailGroup varchar(max), @TextGroup varchar(max), @ProfileName varchar(max)

select @ProfileName = name from msdb..sysmail_profile 
set @EmailGroup = 'brian.woolwine@moserit.com; brett.canova@moserit.com; shaun.watts@moserit.com; harold.brotherton@alliedsolutions.net;steve.moran@alliedsolutions.net' 


IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Alert' AND  TABLE_NAME = 'Parameters'))
BEGIN
	truncate TABLE [alert].[Parameters]

	--Insert Parameter records into PRM_List table
	Insert Into  [alert].[Parameters]                
	(PL_Scope, PL_ParamName, PL_ParamValue, PL_LastModified, PL_LastModifiedBy, PL_Description)
	VALUES
	('All', 'MailProfile', @ProfileName, GETDATE(), SYSTEM_USER, 'Contains the name of the mail profile used by ALL email notifications.')

	Insert Into  [alert].[Parameters]                
	(PL_Scope, PL_ParamName, PL_ParamValue, PL_LastModified, PL_LastModifiedBy, PL_Description)
	VALUES
	('All', 'DBA Alerts', @EmailGroup, GETDATE(), SYSTEM_USER, 'Contains the list of email addresses of which email notification alerts will use.')

END


IF (NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Alert' AND  TABLE_NAME = 'Parameters'))
BEGIN
	CREATE TABLE [alert].[Parameters](
		[PL_ID] [int] IDENTITY(1,1) NOT NULL,
		[PL_Scope] [varchar](256) NULL,
		[PL_ParamName] [varchar](256) NULL,
		[PL_ParamValue] [varchar](1024) NULL,
		[PL_LastModified] [datetime] NULL,
		[PL_LastModifiedBy] [varchar](256) NULL,
		[PL_Description] [varchar](2048) NULL
	) ON [PRIMARY]
	
	--Insert Parameter records into PRM_List table
	Insert Into  [alert].[Parameters]                
	(PL_Scope, PL_ParamName, PL_ParamValue, PL_LastModified, PL_LastModifiedBy, PL_Description)
	VALUES
	('All', 'MailProfile', @ProfileName, GETDATE(), SYSTEM_USER, 'Contains the name of the mail profile used by ALL email notifications.')

	Insert Into  [alert].[Parameters]                
	(PL_Scope, PL_ParamName, PL_ParamValue, PL_LastModified, PL_LastModifiedBy, PL_Description)
	VALUES
	('All', 'DBA Alerts', @EmailGroup, GETDATE(), SYSTEM_USER, 'Contains the list of email addresses of which email notification alerts will use.')

END


