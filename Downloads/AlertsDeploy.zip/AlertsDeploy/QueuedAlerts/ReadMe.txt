
1. Change @notify_email_operator_name value to match desired in the 03AlertSend.sql file
2. Deploy scripts in order of number.  Can use a Powershell script to deploy all .sql files in the folder

