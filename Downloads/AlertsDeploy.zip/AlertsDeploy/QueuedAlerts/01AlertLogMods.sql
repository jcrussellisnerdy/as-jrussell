USE DBA
GO
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME = 'AlertTime' AND TABLE_NAME = 'ALRT_Log')
ALTER TABLE [alert].[Log] ADD AlertTime datetime
GO
ALTER TABLE [alert].[Log] ALTER COLUMN Time int NULL
GO
ALTER TABLE [alert].[Log] ALTER COLUMN Date int NULL
GO

update [alert].[Log]
SET AlertTime = convert(datetime, convert(char(8), Date)+' '+ convert(varchar, dateadd(hour, (Time/10000) % 100, dateadd(minute, (Time/100) % 100, dateadd(second, (Time/1) % 100 , cast('00:00:00' as time(2)))))))
GO

/*
ALTER TABLE [alert].[Log] drop column Date
ALTER TABLE [alert].[Log] drop column Time

select convert(datetime, convert(char(8), Date)+' '+ convert(varchar, dateadd(hour, (Time/10000) % 100, dateadd(minute, (Time/100) % 100, dateadd(second, (Time/1) % 100 , cast('00:00:00' as time(2)))))))
--, *
from [alert].[Log]
*/

